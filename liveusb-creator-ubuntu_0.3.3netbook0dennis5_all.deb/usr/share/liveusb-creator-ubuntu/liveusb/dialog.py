# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'data/liveusb-creator-linux.ui'
#
# Created: Tue Jan 13 15:16:39 2009
#      by: PyQt4 UI code generator 4.3.3
#
# WARNING! All changes made in this file will be lost!

from PyQt4 import QtCore, QtGui

class Ui_Dialog(object):
    def setupUi(self, Dialog):
        Dialog.setObjectName("Dialog")
        Dialog.resize(QtCore.QSize(QtCore.QRect(0,0,437,391).size()).expandedTo(Dialog.minimumSizeHint()))

        sizePolicy = QtGui.QSizePolicy(QtGui.QSizePolicy.Fixed,QtGui.QSizePolicy.Fixed)
        sizePolicy.setHorizontalStretch(0)
        sizePolicy.setVerticalStretch(0)
        sizePolicy.setHeightForWidth(Dialog.sizePolicy().hasHeightForWidth())
        Dialog.setSizePolicy(sizePolicy)

        self.startButton = QtGui.QPushButton(Dialog)
        self.startButton.setEnabled(True)
        self.startButton.setGeometry(QtCore.QRect(136,350,158,34))
        self.startButton.setObjectName("startButton")

        self.textEdit = QtGui.QTextEdit(Dialog)
        self.textEdit.setGeometry(QtCore.QRect(10,200,417,111))

        font = QtGui.QFont()
        font.setPointSize(8)
        self.textEdit.setFont(font)
        self.textEdit.setReadOnly(True)
        self.textEdit.setObjectName("textEdit")

        self.progressBar = QtGui.QProgressBar(Dialog)
        self.progressBar.setGeometry(QtCore.QRect(10,320,421,26))
        self.progressBar.setProperty("value",QtCore.QVariant(0))
        self.progressBar.setObjectName("progressBar")

        self.downloadGroup = QtGui.QGroupBox(Dialog)
        self.downloadGroup.setGeometry(QtCore.QRect(210,80,217,53))

        font = QtGui.QFont()
        font.setPointSize(8)
        self.downloadGroup.setFont(font)
        self.downloadGroup.setObjectName("downloadGroup")

        self.downloadCombo = QtGui.QComboBox(self.downloadGroup)
        self.downloadCombo.setGeometry(QtCore.QRect(10,20,197,28))
        self.downloadCombo.setObjectName("downloadCombo")

        self.label_2 = QtGui.QLabel(Dialog)
        self.label_2.setGeometry(QtCore.QRect(180,100,23,24))

        font = QtGui.QFont()
        font.setFamily("Verdana")
        font.setPointSize(10)
        font.setWeight(75)
        font.setBold(True)
        self.label_2.setFont(font)
        self.label_2.setObjectName("label_2")

        self.groupBox = QtGui.QGroupBox(Dialog)
        self.groupBox.setGeometry(QtCore.QRect(10,80,161,51))

        font = QtGui.QFont()
        font.setPointSize(8)
        self.groupBox.setFont(font)
        self.groupBox.setObjectName("groupBox")

        self.isoBttn = QtGui.QPushButton(self.groupBox)
        self.isoBttn.setGeometry(QtCore.QRect(11,18,141,25))
        self.isoBttn.setObjectName("isoBttn")

        self.groupBox_2 = QtGui.QGroupBox(Dialog)
        self.groupBox_2.setGeometry(QtCore.QRect(10,140,191,53))

        font = QtGui.QFont()
        font.setPointSize(8)
        self.groupBox_2.setFont(font)
        self.groupBox_2.setObjectName("groupBox_2")

        self.driveBox = QtGui.QComboBox(self.groupBox_2)
        self.driveBox.setGeometry(QtCore.QRect(10,20,153,26))
        self.driveBox.setEditable(False)
        self.driveBox.setInsertPolicy(QtGui.QComboBox.InsertAtTop)
        self.driveBox.setDuplicatesEnabled(False)
        self.driveBox.setObjectName("driveBox")

        self.refreshDevicesButton = QtGui.QPushButton(self.groupBox_2)
        self.refreshDevicesButton.setGeometry(QtCore.QRect(160,20,30,26))
        self.refreshDevicesButton.setIcon(QtGui.QIcon(":/refresh.png"))
        self.refreshDevicesButton.setFlat(True)
        self.refreshDevicesButton.setObjectName("refreshDevicesButton")

        self.label = QtGui.QLabel(Dialog)
        self.label.setGeometry(QtCore.QRect(0,0,430,72))
        self.label.setPixmap(QtGui.QPixmap(":/ubuntu-liveusb-header.png"))
        self.label.setObjectName("label")

        self.retranslateUi(Dialog)
        QtCore.QMetaObject.connectSlotsByName(Dialog)

    def retranslateUi(self, Dialog):
        Dialog.setWindowTitle(QtGui.QApplication.translate("Dialog", "Ubuntu Recovery Tool", None, QtGui.QApplication.UnicodeUTF8))
        self.startButton.setWhatsThis(QtGui.QApplication.translate("Dialog", "This button will begin the Recovery USB creation process. You may select an existing recovery image, or the tool will download the latest image, and create the recovery installation on the USB", None, QtGui.QApplication.UnicodeUTF8))
        self.startButton.setText(QtGui.QApplication.translate("Dialog", "Start", None, QtGui.QApplication.UnicodeUTF8))
        self.textEdit.setWhatsThis(QtGui.QApplication.translate("Dialog", "This is the status console, where all messages get written to.", None, QtGui.QApplication.UnicodeUTF8))
        self.progressBar.setWhatsThis(QtGui.QApplication.translate("Dialog", "This is the progress bar that will indicate how far along in the creation process you are", None, QtGui.QApplication.UnicodeUTF8))
        self.downloadGroup.setWhatsThis(QtGui.QApplication.translate("Dialog", "If you do not select an existing recovery image, the selected release will be downloaded for you.", None, QtGui.QApplication.UnicodeUTF8))
        self.downloadGroup.setTitle(QtGui.QApplication.translate("Dialog", "Download recovery image", None, QtGui.QApplication.UnicodeUTF8))
        self.label_2.setText(QtGui.QApplication.translate("Dialog", "or", None, QtGui.QApplication.UnicodeUTF8))
        self.groupBox.setWhatsThis(QtGui.QApplication.translate("Dialog", "This button allows you to browse for an existing recovery image that you have previously downloaded.  If you do not select one, a release will be downloaded for you automatically.", None, QtGui.QApplication.UnicodeUTF8))
        self.groupBox.setTitle(QtGui.QApplication.translate("Dialog", "Use existing recovery image", None, QtGui.QApplication.UnicodeUTF8))
        self.isoBttn.setText(QtGui.QApplication.translate("Dialog", "Browse", None, QtGui.QApplication.UnicodeUTF8))
        self.isoBttn.setShortcut(QtGui.QApplication.translate("Dialog", "Alt+B", None, QtGui.QApplication.UnicodeUTF8))
        self.groupBox_2.setWhatsThis(QtGui.QApplication.translate("Dialog", "This is the USB stick that you want to install your recovery image on.  This device must be formatted with the FAT filesystem.", None, QtGui.QApplication.UnicodeUTF8))
        self.groupBox_2.setTitle(QtGui.QApplication.translate("Dialog", "Target Device", None, QtGui.QApplication.UnicodeUTF8))

import resources_rc
